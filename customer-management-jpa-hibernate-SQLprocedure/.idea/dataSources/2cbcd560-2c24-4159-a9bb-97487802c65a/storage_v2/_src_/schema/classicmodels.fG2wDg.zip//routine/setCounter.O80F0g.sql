create
    definer = root@localhost procedure setCounter(INOUT counter int, IN increment int)
begin
    set counter = counter + increment;
end;

